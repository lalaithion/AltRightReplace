This script goes through every web page you visit and changes the phrase "Alt-Right" to "Neo-Nazi". Report bugs at: https://github.com/lalaithion/AltRightReplace/issues

The logo I use is cited by source, fair use, https://en.wikipedia.org/w/index.php?curid=34084026.
